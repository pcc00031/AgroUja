# CHANGELOG - AGROUJA


## [0.0.1] - 2021-03-22
#### Added

- algunas clases java auxiliares - @cga00037, @cmp00070
- vista principal de productos (/productos/index) - @pcc00031
- vista de agregar producto (/productos/agregar) - @pcc00031
- vista de ver producto (/productos/visualizar) - @pcc00031
- vista principal (/index) - @cmp00070
- vista de registro (/registro) - @cmp00070
- vista de iniciar sesión (/login) - @cmp00070
- vista de contacto (/contacto) - @cga00037
- vista de editar producto (/productos/editar) - @cga00037
- vista visualizar usuario (/usuario/index)- @jgr00059
- vista de editar usuario (/usuario/editar) - @jgr00059
- layouts y archivos .css - @pcc00031 , @cmp00070 , @cga00037 , @jgr00059

### Fixed

- solapamiento de funciones .css
- apartados visuales 







