# AgroUja

![fondo](https://user-images.githubusercontent.com/49394226/111911219-e9466700-8a64-11eb-930f-0e8f88fcbbf9.jpg)

## 🌳 Descripción

El propósito de nuestro proyecto es facilitar a los agricultores un portal de compraventa y alquiler de productos y maquinaria agrícola.
La página estaría orientada para particulares, de esta forma podrían conseguir ahorrar algo de dinero a la hora de publicar los productos que ya no necesiten. Además otros particulares podrían beneficiarse de adquirir este tipo de mercancía con una significativa reducción del coste final.

## 📢 Requisitos funcionales

El proyecto contará con:

- Registro e inicio/cierre sesión de usuario.
- Sistema para añadir y/o comprar/alquilar productos.
- Posibilidad de valorar y comentar los productos.
- Formulario de contacto
